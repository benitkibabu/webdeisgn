package com.benit.kibabu.ncistudentcardreceiver;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity implements NfcAdapter.CreateNdefMessageCallback {

    NfcAdapter nfcAdapter;
    DatabaseReference db;
    private ValueEventListener valueEventListener;
    private List<Attendance> attendanceList;

    SharedPreferences preferences;

    TextView infoTextView, timeTv, moduleTv, dateTv;

    String moduleName, sessionDate, startTime,endTime;

    private static final boolean AUTO_HIDE = true;
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

    private static final int UI_ANIMATION_DELAY = 300;
    private final Handler mHideHandler = new Handler();
    private View mContentView;
    private final Runnable mHidePart2Runnable = new Runnable() {
        @SuppressLint("InlinedApi")
        @Override
        public void run() {
            // Delayed removal of status and navigation bar

            // Note that some of these constants are new as of API 16 (Jelly Bean)
            // and API 19 (KitKat). It is safe to use them, as they are inlined
            // at compile-time and do nothing on earlier devices.
            mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    };
    private View mControlsView;
    private final Runnable mShowPart2Runnable = new Runnable() {
        @Override
        public void run() {
            // Delayed display of UI elements
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.show();
            }
            mControlsView.setVisibility(View.VISIBLE);
        }
    };
    private boolean mVisible;
    private final Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            hide();
        }
    };
    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    private final View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (AUTO_HIDE) {
                delayedHide(AUTO_HIDE_DELAY_MILLIS);
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        attendanceList = new ArrayList<>();

        mVisible = true;
        mControlsView = findViewById(R.id.fullscreen_content_controls);
        mContentView = findViewById(R.id.fullscreen_content);

        infoTextView = (TextView) findViewById(R.id.info_text_view);
        dateTv = (TextView) findViewById(R.id.dateTv);
        timeTv = (TextView) findViewById(R.id.timeTv);
        moduleTv = (TextView) findViewById(R.id.moduleTv);

        mContentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggle();
            }
        });

        Button sessionBtn  = (Button) findViewById(R.id.sessionBtn);
        sessionBtn.setOnTouchListener(mDelayHideTouchListener);
        sessionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SessionActivity.class));
            }
        });

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if(nfcAdapter == null){
            showToast("You need NFC to use this App");
        }else if(!nfcAdapter.isEnabled()){
            showToast("Please enable NFC!");
            startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
        }
        else if(!nfcAdapter.isNdefPushEnabled()){
            showToast("Please enable Android Beam");
            startActivity(new Intent(Settings.ACTION_NFCSHARING_SETTINGS));
        }

        db = FirebaseDatabase.getInstance().getReference().child("attendances");

        nfcAdapter.setNdefPushMessageCallback(this, this);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        delayedHide(100);
    }

    private void toggle() {
        if (mVisible) {
            hide();
        } else {
            show();
        }
    }

    private void hide() {
        // Hide UI first
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        mControlsView.setVisibility(View.GONE);
        mVisible = false;

        // Schedule a runnable to remove the status and navigation bar after a delay
        mHideHandler.removeCallbacks(mShowPart2Runnable);
        mHideHandler.postDelayed(mHidePart2Runnable, UI_ANIMATION_DELAY);
    }

    @SuppressLint("InlinedApi")
    private void show() {
        // Show the system bar
        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        mVisible = true;

        // Schedule a runnable to display UI elements after a delay
        mHideHandler.removeCallbacks(mHidePart2Runnable);
        mHideHandler.postDelayed(mShowPart2Runnable, UI_ANIMATION_DELAY);
    }

    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        super.onNewIntent(intent);

    }

    @Override
    public void onResume() {
        super.onResume();
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        if(!preferences.getBoolean("session", false)){
            showToast("Session Not Set!");
            startActivity(new Intent(MainActivity.this, SessionActivity.class));

        }else{
            if(infoTextView != null){
                moduleName = preferences.getString("moduleName", "Not Set");
                sessionDate = preferences.getString("sessionDate", "Not Set");
                startTime = preferences.getString("startTime", "Not Set");
                endTime = preferences.getString("endTime", "Not Set");

                moduleTv.setText(moduleName);
                dateTv.setText(sessionDate);
                timeTv.setText(startTime + " - " + endTime);
            }
        }
        // Check to see that the Activity started due to an Android Beam
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
        }
    }

    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
        String msg = "Present at " + System.currentTimeMillis();
        NdefMessage nMsg = new NdefMessage(
                new NdefRecord[]{
                        NdefRecord.createTextRecord("text/plain", msg)
                }
        );
        return nMsg;
    }

    void processIntent(Intent intent) {
        Parcelable[] parcelables = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
        if(parcelables != null){
            NdefMessage[] messages = new NdefMessage[parcelables.length];
            for(int i = 0; i< parcelables.length; i++){
                messages[i] = (NdefMessage) parcelables[i];
            }

            NdefMessage message =  messages[0];
            int index = 3;

            String uid = new String(message.getRecords()[0].getPayload());
            uid = uid.substring(index, uid.length());

            String studentNo = new String(message.getRecords()[1].getPayload());
            studentNo = studentNo.substring(index, studentNo.length());

            String scanTime = new String(message.getRecords()[3].getPayload());
            scanTime = scanTime.substring(index, scanTime.length());

            String scanDate = new String(message.getRecords()[2].getPayload());
            scanDate = scanDate.substring(index, scanDate.length());

            saveToDatabase(new Attendance(uid, sessionDate ,studentNo, moduleName,
                    scanDate, scanTime, startTime, endTime));
        }
    }

    boolean present;
    void saveToDatabase(final Attendance att){
        present = false;
        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                attendanceList = new ArrayList<>();
                for(DataSnapshot child: dataSnapshot.getChildren()){
                    Attendance a = child.getValue(Attendance.class);
                    if(a.getUid().equals(att.getUid())) {
                        attendanceList.add(a);
                    }
                }

                if(attendanceList.isEmpty() ){
                    if(!present) {
                        showToast("list is empty");
                        db.push().setValue(att).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (!task.isSuccessful()) {
                                    showToast("failed to save to database");
                                } else {
                                    String txt = att.getStudentNo() + " Present!";
                                    infoTextView.setText(txt);
                                    showToast(att.getStudentNo() + " Present at: " + att.getScanTime());
                                }
                            }
                        });
                        present = true;
                    }
                }else {
                    for (Attendance a : attendanceList) {
                        if (a.getUid().equals(att.getUid())) {
                            if (a.getModuleName().equals(moduleName) && a.getSessionDate().equals(sessionDate) &&
                                    a.getStartTime().equals(startTime)) {
                                if (isTimeBetween(getDate(a.getStartTime()),
                                        getDate(a.getEndTime()), getDate(att.getScanTime()))) {
                                    present = true;
                                    String txt = att.getStudentNo() + " already scanned!!";
                                    infoTextView.setText(txt);
                                    showToast(txt);
                                    break;
                                }
                            }
                        }
                    }
                    if (!present) {
                        db.push().setValue(att).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (!task.isSuccessful()) {
                                    showToast("failed to save to database");
                                } else {
                                    String txt = att.getStudentNo() + " Present!";
                                    infoTextView.setText(txt);
                                }
                            }
                        });
                        present = true;
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                showToast("Error: " + databaseError.getMessage());
            }
        };
        db.addValueEventListener(listener);
        valueEventListener = listener;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();

        if(valueEventListener != null){
            db.removeEventListener(valueEventListener);
        }
    }
}

