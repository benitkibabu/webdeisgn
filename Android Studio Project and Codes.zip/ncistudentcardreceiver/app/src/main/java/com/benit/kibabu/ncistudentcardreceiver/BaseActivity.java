package com.benit.kibabu.ncistudentcardreceiver;

import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Benit Kibabu on 17/06/2017.
 */

public class BaseActivity extends AppCompatActivity {
    public void showToast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    public boolean isValidEditText(EditText editText){
        if(editText.getText().toString().isEmpty()){
            editText.setError(getString(R.string.required));
            return false;
        }else{
            return true;
        }
    }

    DateFormat dateTimeFormat =  new SimpleDateFormat("HH:mm");
    public Date getDate(String date)  {

        try {
            return dateTimeFormat.parse(date);
        } catch (ParseException e) {
           return new Date();
        }
    }

    public final boolean isTimeBetween(Date startTime, Date endTime, Date validateTime) {
        boolean validTimeFlag = false;

        if (endTime.compareTo(startTime) <= 0) {
            if (validateTime.compareTo(endTime) < 0 || validateTime.compareTo(startTime) >= 0) {
                validTimeFlag = true;
            }
        } else if (validateTime.compareTo(endTime) < 0 && validateTime.compareTo(startTime) >= 0) {
            validTimeFlag = true;
        }

        return validTimeFlag;
    }
}
