package com.benit.kibabu.ncistudentcardreceiver;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.NavUtils;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

/**
 * Created by Benit Kibabu on 01/07/2017.
 */

public class SessionActivity extends BaseActivity {

    EditText moduleNameEt, dateEt, startTimeEt, endTimeEt;
    Button createBtn;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    String startTime ="", endTime="", date="";

    private void saveData(Session s){
        editor = preferences.edit();
        editor.putBoolean("session", true);
        editor.putString("moduleName", s.getModuleName());
        editor.putString("sessionDate", s.getDate());
        editor.putString("startTime", s.getStartTime());
        editor.putString("endTime", s.getEndTime());

        editor.apply();
    }

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_session);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);

        moduleNameEt = (EditText) findViewById(R.id.moduleNameET);
        createBtn = (Button) findViewById(R.id.creatBtn);

        dateEt = (EditText) findViewById(R.id.dateET);
        startTimeEt = (EditText) findViewById(R.id.startTimeET);
        endTimeEt = (EditText) findViewById(R.id.endTimeET);

        dateEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentDate=Calendar.getInstance();
                int mYear=mcurrentDate.get(Calendar.YEAR);
                int mMonth=mcurrentDate.get(Calendar.MONTH);
                int mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker = new DatePickerDialog(SessionActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker,
                                          int year, int month, int day) {
                        month = month+1;

                        if(month < 10 && day < 10){
                            date = year + "-0" + month + "-0" + day;
                        }else if(month < 10){
                            date = year + "-0" + month + "-" + day;
                        }else if(day<10){
                            date = year + "-" + month + "-0" + day;
                        }
                        else {
                            date = year + "-" + month + "-" + day;
                        }
                        dateEt.setText(date);
                    }
                },mYear, mMonth, mDay);
                mDatePicker.setTitle("Select sessionDate");
                mDatePicker.show();
            }

        });
        startTimeEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);

                TimePickerDialog tp = new TimePickerDialog(SessionActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                                if(hourOfDay < 10 && minute < 10){
                                    startTime = "0"+hourOfDay + ":0" + minute;
                                }else if(hourOfDay < 10){
                                    startTime = "0"+hourOfDay + ":" + minute;
                                }else if(minute < 10){
                                    startTime = hourOfDay + ":0" + minute;
                                }else {
                                    startTime = hourOfDay + ":" + minute;
                                }

                                startTimeEt.setText(startTime);


                            }
                        }, hour, minute,
                        DateFormat.is24HourFormat(SessionActivity.this));
                tp.setTitle("Select Start Time");
                tp.show();
            }
        });
        endTimeEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);
                TimePickerDialog tp = new TimePickerDialog(SessionActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                if(hourOfDay < 10 && minute < 10){
                                        endTime = "0"+hourOfDay + ":0" + minute;
                                }else if(hourOfDay < 10){
                                        endTime = "0"+hourOfDay + ":" + minute;
                                }else if(minute < 10){
                                    endTime = hourOfDay + ":0" + minute;
                                }else {
                                    endTime = hourOfDay + ":" + minute;
                                }
                                endTimeEt.setText(endTime);
                            }
                        }, hour, minute,
                        DateFormat.is24HourFormat(SessionActivity.this));
                tp.setTitle("Select End Time");
                tp.show();
            }
        });

        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isValidEditText(moduleNameEt) && isValidEditText(dateEt)
                        && isValidEditText(startTimeEt) && isValidEditText(endTimeEt)) {
                    Session session =
                            new Session(moduleNameEt.getText().toString(),
                                    dateEt.getText().toString(), startTimeEt.getText().toString(),
                                    endTimeEt.getText().toString());
                    saveData(session);
                    finish();
                }
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.session_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.home){
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        else if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
