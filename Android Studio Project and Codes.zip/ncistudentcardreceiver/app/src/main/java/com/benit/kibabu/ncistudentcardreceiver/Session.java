package com.benit.kibabu.ncistudentcardreceiver;

import java.io.Serializable;

/**
 * Created by Benit Kibabu on 01/07/2017.
 */

public class Session implements Serializable{
    String moduleName;
    String date;
    String startTime;
    String endTime;

    public Session() {
    }

    public Session(String moduleName, String date, String startTime, String endTime) {
        this.moduleName = moduleName;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getDate() {
        return date;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }
}
