package com.benit.kibabu.studentcardapp.bases;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.Toast;

import com.benit.kibabu.studentcardapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Benit Kibabu on 17/06/2017.
 */

public class BaseActivity extends AppCompatActivity {
    private ProgressDialog dialog;

    public void showDialog(String message){
        if(dialog == null){
            dialog = new ProgressDialog(this);
        }
        dialog.setMessage(message);
        dialog.setCancelable(false);
        dialog.show();
    }

    public void showDialog(){
        if(dialog == null){
            dialog = new ProgressDialog(this);
        }
        dialog.setMessage("Loading....");
        dialog.setCancelable(false);
        dialog.show();
    }

    public void hideDialog(){
        if(dialog != null && dialog.isShowing()){
            dialog.dismiss();
        }
    }

    public void showToast(String message){
        Toast.makeText(this,message, Toast.LENGTH_LONG).show();
    }

    public FirebaseUser getUser(){
        return FirebaseAuth.getInstance().getCurrentUser();
    }

    public boolean isValidEditText(EditText editText){
        if(editText.getText().toString().isEmpty()){
            editText.setError(getString(R.string.required_text));
            return false;
        }else{
            return true;
        }
    }
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    DateFormat timeFormat = new SimpleDateFormat("HH:mm");

    public String getStringDate(Date date){
        return dateFormat.format(date);
    }
    public String getStringTime(Date date){
        return timeFormat.format(date);
    }

}
