package com.benit.kibabu.studentcardapp.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.benit.kibabu.studentcardapp.R;
import com.benit.kibabu.studentcardapp.models.Attendance;

import java.util.List;


/**
 * Created by Benit Kibabu on 20/06/2017.
 */

public class AttendanceListAdapter extends ArrayAdapter<Attendance> {
    List<Attendance> attendanceList;
    Context context;
    int resource;
    public AttendanceListAdapter(Context context, int resource, List<Attendance> objects) {
        super(context, resource, objects);
        this.context = context;
        attendanceList = objects;
        this.resource = resource;
    }

    @Override
    public int getCount() {
        return attendanceList.size();
    }

    public void updateAll(List<Attendance> attendances){
        attendanceList.clear();
        attendanceList.addAll(attendances);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        AttendanceHolder holder;
        Attendance attendance = getItem(position);

        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(resource,parent, false);

            holder = new AttendanceHolder();
            holder.container = (RelativeLayout) convertView.findViewById(R.id.container);
            holder.moduletv = (TextView) convertView.findViewById(R.id.module_tv);
            holder.datetv = (TextView) convertView.findViewById(R.id.date_tv);
            holder.timeTv = (TextView) convertView.findViewById(R.id.timeTv);

            convertView.setTag(holder);

        }else{
            holder = (AttendanceHolder) convertView.getTag();
        }

        holder.moduletv.setText(attendance.getModuleName());
        //Date dat = new Date(attendance.getScanTime());
        holder.datetv.setText("Date: "+ attendance.getSessionDate() + " Start: " +
                attendance.getStartTime() + " - End: " + attendance.getEndTime());
        holder.timeTv.setText("Present at: " + attendance.getScanDate() + " - " + attendance.getScanTime());

        return convertView;
    }

    private static class AttendanceHolder{
        RelativeLayout container;
        TextView moduletv, datetv, timeTv;
    }
}
