package com.benit.kibabu.studentcardapp.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.benit.kibabu.studentcardapp.R;
import com.benit.kibabu.studentcardapp.adapters.AttendanceListAdapter;
import com.benit.kibabu.studentcardapp.bases.BaseFragment;
import com.benit.kibabu.studentcardapp.models.Attendance;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Benit Kibabu on 19/06/2017.
 */

public class AttendanceFragment extends BaseFragment {

    List<Attendance> attendanceList;
    AttendanceListAdapter adapter;

    DatabaseReference db;
    ValueEventListener valueEventListener;
    FirebaseUser user;

    LinearLayout loadingContainer;

    public AttendanceFragment(){

    }
    public static AttendanceFragment newInstance(){
        AttendanceFragment fragment = new AttendanceFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = FirebaseDatabase.getInstance().getReference().child("attendances");
        user = getUser();
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_attendance, container, false);
        attendanceList = new ArrayList<>();
//        attendanceList.add(new Attendance("XYZ", "2017-07-02", "XYZ01", "Porject",
//                "2017-07-02", "12:00", "11:00", "13:00"));

        loadingContainer = (LinearLayout) view.findViewById(R.id.loadingContainer);
        ListView listView = (ListView) view.findViewById(R.id.listview);
        adapter = new AttendanceListAdapter(getActivity().getBaseContext(),
                R.layout.attendance_item, attendanceList);
        listView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        loadingContainer.setVisibility(View.VISIBLE);
        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                attendanceList = new ArrayList<>();

                for(DataSnapshot child: dataSnapshot.getChildren()){
                    Attendance a = child.getValue(Attendance.class);

                    if(a.getUid().equals(user.getUid())) {
                        attendanceList.add(a);
                    }
                }
                adapter.updateAll(attendanceList);
                loadingContainer.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                hideDialog();
                showToast("The read failed: " + databaseError.getMessage());
                loadingContainer.setVisibility(View.GONE);
            }
        };

        db.addValueEventListener(listener);

        valueEventListener = listener;
    }

    @Override
    public void onStop() {
        super.onStop();
        if(valueEventListener != null){
            db.removeEventListener(valueEventListener);
        }
    }


}
