package com.benit.kibabu.studentcardapp.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.benit.kibabu.studentcardapp.R;
import com.benit.kibabu.studentcardapp.bases.BaseFragment;
import com.google.firebase.auth.FirebaseUser;

public class HomeFragment extends BaseFragment {
    FirebaseUser user;
    public HomeFragment() {
    }

    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
        user = getUser();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        TextView studentNoTv = (TextView) rootView.findViewById(R.id.studentNoTv);
        TextView emailTv = (TextView) rootView.findViewById(R.id.emailTv);
        if(user != null) {
            studentNoTv.setText(user.getEmail().substring(0, user.getEmail().indexOf('@')));
            emailTv.setText(user.getEmail());
        }
        return rootView;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
